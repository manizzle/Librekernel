#ifndef UTIL_LINUX_ENV_H
#define UTIL_LINUX_ENV_H

extern void sanitize_env (void);
extern char *safe_getenv(const char *arg);

#endif /* UTIL_LINUX_ENV_H */

